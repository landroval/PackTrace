﻿Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture;
Get-CimInstance Win32_Processor | Select-Object Name,Architecture;
$PSVersionTable.PSVersion;

﻿$StateSource = Join-Path $env:LOCALAPPDATA ('PackTrace-prueba-' + [Guid]::NewGuid().ToString('N'));
$Project = Join-Path $StateSource 'proyecto con espacios';
$Modules = Join-Path $Project 'node_modules\packtrace-fixture';
$Config = Join-Path $StateSource 'config-vacia';
if (Test-Path $StateSource) { throw 'La carpeta ya existe: detente.' };
New-Item -ItemType Directory -Path $StateSource | Out-Null;
New-Item -ItemType Directory -Path $Modules,$Config | Out-Null;
$env:APPDATA = $Config;
$State = Join-Path $StateSource 'sin-datos';
$Utf8 = [Text.UTF8Encoding]::new($false);
$M = @{
  name='packtrace-fixture-root'; version='1.0.0'; private=$true;
  packageManager='npm@9.9.4';
  dependencies=@{ 'packtrace-fixture'='1.0.0' };
};
$L = @{ lockfileVersion=3; packages=@{
  ''=@{ dependencies=@{ 'packtrace-fixture'='1.0.0' } };
  'node_modules/packtrace-fixture'=@{
    name='packtrace-fixture'; version='1.0.0';
  };
} };
$P = @{ name='packtrace-fixture'; version='1.0.0' };
[IO.File]::WriteAllText((Join-Path $Project 'package.json'), ($M | ConvertTo-Json -Depth 10), $Utf8);
[IO.File]::WriteAllText((Join-Path $Project 'package-lock.json'), ($L | ConvertTo-Json -Depth 10), $Utf8);
[IO.File]::WriteAllText((Join-Path $Modules 'package.json'), ($P | ConvertTo-Json -Depth 10), $Utf8);
$Scan = @('scan','--manager','npm@9.9.4','--checks','malicious','--state-dir',$State,'--privacy','portable');

﻿if ($ScanExit -ne 3) { throw 'Anota scan y su error: detente.' };
$Json = & $Exe @Scan --format json $Project;
$JsonExit = $LASTEXITCODE;
if ($JsonExit -ne 3) { throw 'Anota JSON y su error: detente.' };
$Text = $Json -join "`n";
$Text | ConvertFrom-Json | Out-Null;
$Report = Join-Path $StateSource 'resultado-portable.json';
[IO.File]::WriteAllText($Report, $Text, $Utf8);
"JSON=$JsonExit; archivo=$Report";
